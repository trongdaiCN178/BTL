import { useEffect, useState } from 'react';
import { FaSearch } from 'react-icons/fa';

const API_BASE = '';
async function fetchJson(url) {
    const res = await fetch(url);
    if (!res.ok) throw new Error(await res.text());
    return res.json();
}

// "Từ điển" dịch từ khóa tiếng Việt sang mã hệ thống
const keywordMap = {
    // Thiết bị
    'den': 'lamp',
    'đèn': 'lamp',
    'quat': 'fan',
    'quạt': 'fan',
    'dieu hoa': 'air',
    'điều hòa': 'air',
    // Trạng thái
    'bat': 'on',
    'bật': 'on',
    'tat': 'off',
    'tắt': 'off',
};

export default function ActionHistory() {
    const [rows, setRows] = useState([]);
    const [page, setPage] = useState(1);
    const [size, setPageSize] = useState(10);
    const [info, setInfo] = useState({ numPage: 1 });
    const [error, setError] = useState('');

    const [search, setSearch] = useState('');
    const [searchBy, setSearchBy] = useState('id');
    const [sortBy, setSortBy] = useState('time');
    const [order, setOrder] = useState('DESC');

    // Tự động tải lại khi sắp xếp hoặc phân trang thay đổi
    useEffect(() => {
        // Chỉ tải lại nếu không có tìm kiếm đang hoạt động
        if (search.trim() === '') {
            load(page, size);
        }
    }, [page, size, sortBy, order]);

    async function load(page, size, isSearching = false) {
        setError('');
        try {
            let data;
            const sortParams = `sortBy=${sortBy}&order=${order}`;
            let searchTerm = search.trim();
            let searchType = searchBy;

            // SỬA LỖI TẠI ĐÂY: Logic dịch từ khóa tiếng Việt
            if (isSearching && searchTerm !== '') {
                const normalizedSearch = searchTerm.toLowerCase();
                // Nếu từ khóa có trong "từ điển", dùng giá trị đã dịch
                // Áp dụng cho cả 'device_id' và 'status'
                if (keywordMap[normalizedSearch]) {
                    searchTerm = keywordMap[normalizedSearch];
                }
            }

            if (searchTerm !== '') {
                const searchParams = `type=${searchType}&search=${encodeURIComponent(searchTerm)}&page=${page}&size=${size}&${sortParams}`;
                data = await fetchJson(`${API_BASE}/api/action/search?${searchParams}`);
                setRows(data.getActionSearch || []);
                setInfo(data.getActionSearchInfo || { numPage: 1 });
            } else {
                const params = `page=${page}&size=${size}&${sortParams}`;
                data = await fetchJson(`${API_BASE}/api/action/data?${params}`);
                setRows(data.getActionPage || []);
                setInfo(data.getActionInfo || { numPage: 1 });
            }
        } catch (e) {
            setError(String(e.message || e));
        }
    }

    function handleSearch(e) {
        e.preventDefault();
        setPage(1);
        load(1, size, true); // Đặt cờ isSearching thành true khi nhấn nút
    }

    function formatTime(timeStr) {
        if (!timeStr) return '';
        const d = new Date(timeStr);
        const pad = n => n.toString().padStart(2, '0');
        return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
    }

    function getDeviceLabel(deviceId) {
        const labels = { 'fan': 'Quạt', 'air': 'Điều hòa', 'lamp': 'Đèn' };
        return labels[deviceId] || deviceId;
    }

    return (
        <>
            <div className="header"><h1>Action History</h1></div>
            <p className="page-subtitle">Lịch sử sự kiện</p>

            <div className="content-card">
                <div className="filter-toolbar">
                    <form onSubmit={handleSearch} className="filter-group">
                        <div className="search-wrapper">
                            <FaSearch className="icon" />
                            <input
                                className="input"
                                placeholder="Nhập từ khóa..."
                                value={search}
                                onChange={e => setSearch(e.target.value)}
                            />
                        </div>
                        <select className="input" value={searchBy} onChange={e => setSearchBy(e.target.value)}>
                            <option value="id">Tìm theo ID</option>
                            <option value="device_id">Tìm theo Thiết bị</option>
                            <option value="status">Tìm theo Hoạt động</option>
                            <option value="time">Tìm theo Thời gian</option>
                        </select>
                        <button type="submit" className="btn btn-primary">Tìm kiếm</button>
                    </form>

                    <div className="filter-group">
                        <select className="input" value={sortBy} onChange={e => setSortBy(e.target.value)}>
                            <option value="time">Sắp xếp theo Thời gian</option>
                            <option value="id">Sắp xếp theo ID</option>
                        </select>
                        <select className="input" value={order} onChange={e => setOrder(e.target.value)}>
                            <option value="DESC">Giảm dần</option>
                            <option value="ASC">Tăng dần</option>
                        </select>
                    </div>
                </div>

                {error && <div style={{ color: '#b91c1c', marginBottom: 8 }}>Lỗi: {error}</div>}

                <table className="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Thiết bị</th>
                            <th>Hoạt Động</th>
                            <th>Last update</th>
                        </tr>
                    </thead>
                    <tbody>
                        {rows.map((r, i) => (
                            <tr key={r.id || i}>
                                <td>{r.id}</td>
                                <td>{getDeviceLabel(r.device_id)}</td>
                                <td>{r.status === 'on' ? 'Bật' : 'Tắt'}</td>
                                <td>{formatTime(r.time)}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>

                <div className="pagination">
                    <div className="rows-per-page">
                        <span>Rows per page:</span>
                        <select value={size} onChange={e => { setPageSize(Number(e.target.value)); setPage(1); }}>
                            <option value="10">10</option>
                            <option value="20">20</option>
                            <option value="50">50</option>
                        </select>
                    </div>
                    <div className="pagination-controls">
                        <span>{page} of {info.numPage}</span>
                        <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page <= 1}>{"<"}</button>
                        <button onClick={() => setPage(p => Math.min(info.numPage, p + 1))} disabled={page >= info.numPage}>{">"}</button>
                    </div>
                </div>
            </div>
        </>
    );
}