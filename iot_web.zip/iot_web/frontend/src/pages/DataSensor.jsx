import { useEffect, useState } from 'react';
import { FaSearch } from 'react-icons/fa';

const API_BASE = '';
async function fetchJson(url) {
    const res = await fetch(url);
    if (!res.ok) throw new Error(await res.text());
    return res.json();
}

export default function DataSensor() {
    const [rows, setRows] = useState([]);
    const [page, setPage] = useState(1);
    const [size, setPageSize] = useState(10);
    const [info, setInfo] = useState({ numPage: 1 });
    const [error, setError] = useState('');

    // State cho việc tìm kiếm
    const [search, setSearch] = useState('');
    const [searchBy, setSearchBy] = useState('all');
    const [activeSearch, setActiveSearch] = useState(''); // Lưu giá trị tìm kiếm đang được áp dụng

    // State cho việc sắp xếp
    const [sortBy, setSortBy] = useState('time'); // Giá trị sắp xếp đang được áp dụng
    const [order, setOrder] = useState('DESC');   // Thứ tự đang được áp dụng
    const [tempSortBy, setTempSortBy] = useState('time'); // Giá trị tạm thời trên UI
    const [tempOrder, setTempOrder] = useState('DESC');   // Thứ tự tạm thời trên UI

    // Tải lại dữ liệu khi các giá trị đang áp dụng thay đổi
    useEffect(() => {
        load(page, size);
    }, [page, size, sortBy, order, activeSearch]);

    async function load(page, size) {
        setError('');
        try {
            let data;
            const sortParams = `sortBy=${sortBy}&order=${order}`;

            if (activeSearch.trim() !== '') {
                const searchParams = `type=${searchBy}&search=${encodeURIComponent(activeSearch)}&page=${page}&size=${size}&${sortParams}`;
                data = await fetchJson(`${API_BASE}/api/sensor/search?${searchParams}`);
                setRows(data.getSearch || []);
                setInfo(data.getSearchInfo || { numPage: 1 });
            } else {
                const params = `page=${page}&size=${size}&${sortParams}`;
                data = await fetchJson(`${API_BASE}/api/sensor/data?${params}`);
                setRows(data.getPage || []);
                setInfo(data.getInfo || { numPage: 1 });
            }
        } catch (e) {
            setError(String(e.message || e));
        }
    }

    // Xử lý khi nhấn nút "Tìm kiếm"
    function handleSearch(e) {
        e.preventDefault();
        setPage(1);
        setActiveSearch(search); // Áp dụng giá trị tìm kiếm từ ô input
    }

    // Xử lý khi nhấn nút "Sắp xếp"
    function handleSort(e) {
        e.preventDefault();
        setPage(1);
        setSortBy(tempSortBy); // Áp dụng giá trị sắp xếp từ dropdown
        setOrder(tempOrder);   // Áp dụng thứ tự từ dropdown
    }

    function formatTime(timeStr) {
        if (!timeStr) return '';
        const d = new Date(timeStr);
        const pad = n => n.toString().padStart(2, '0');
        return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
    }

    return (
        <>
            <div className="header"><h1>Data Sensor</h1></div>
            <p className="page-subtitle">Quản lý thông số cảm biến (real-time)</p>

            <div className="content-card">
                <div className="filter-toolbar">
                    {/* Nhóm Tìm kiếm */}
                    <form onSubmit={handleSearch} className="filter-group">
                        <div className="search-wrapper">
                            <FaSearch className="icon" />
                            <input
                                className="input"
                                placeholder="Nhập từ khóa tìm kiếm..."
                                value={search}
                                onChange={e => setSearch(e.target.value)}
                            />
                        </div>
                        <select className="input" value={searchBy} onChange={e => setSearchBy(e.target.value)}>
                            <option value="all">Tìm theo Tất cả</option>
                            <option value="id">ID</option>
                            <option value="time">Thời gian</option>
                            <option value="temperature">Nhiệt độ</option>
                            <option value="humidity">Độ ẩm</option>
                            <option value="light">Ánh sáng</option>
                        </select>
                        <button type="submit" className="btn btn-primary">Tìm kiếm</button>
                    </form>

                    {/* Nhóm Sắp xếp */}
                    <form onSubmit={handleSort} className="filter-group">
                        <select className="input" value={tempSortBy} onChange={e => setTempSortBy(e.target.value)}>
                            <option value="time">Sắp xếp theo Thời gian</option>
                            <option value="id">ID</option>
                            <option value="temperature">Nhiệt độ</option>
                            <option value="humidity">Độ ẩm</option>
                            <option value="light">Ánh sáng</option>
                        </select>
                        <select className="input" value={tempOrder} onChange={e => setTempOrder(e.target.value)}>
                            <option value="DESC">Giảm dần</option>
                            <option value="ASC">Tăng dần</option>
                        </select>
                        <button type="submit" className="btn btn-secondary">Sắp xếp</button>
                    </form>
                </div>

                {error && <div style={{ color: '#b91c1c', marginBottom: 8 }}>Lỗi: {error}</div>}

                <table className="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nhiệt độ</th>
                            <th>Độ ẩm</th>
                            <th>Ánh sáng</th>
                            <th>Thời gian</th>
                        </tr>
                    </thead>
                    <tbody>
                        {rows.map((r, i) => (
                            <tr key={r.id || i}>
                                <td>{r.id}</td>
                                <td>{r.temperature}°C</td>
                                <td>{r.humidity}%</td>
                                <td>{r.light} Lux</td>
                                <td>{formatTime(r.time)}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>

                <div className="pagination">
                    <div className="rows-per-page">
                        <span>Rows per page:</span>
                        <select value={size} onChange={e => { setPageSize(Number(e.target.value)); setPage(1); }}>
                            <option value="10">10</option>
                            <option value="20">20</option>
                            <option value="50">50</option>
                        </select>
                    </div>
                    <div className="pagination-controls">
                        <span>{page} of {info.numPage}</span>
                        <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page <= 1}>{"<"}</button>
                        <button onClick={() => setPage(p => Math.min(info.numPage, p + 1))} disabled={page >= info.numPage}>{">"}</button>
                    </div>
                </div>
            </div>
        </>
    );
}