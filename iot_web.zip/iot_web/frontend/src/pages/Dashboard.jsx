import { CategoryScale, Chart, Legend, LinearScale, LineController, LineElement, PointElement, Tooltip } from 'chart.js';
import { useEffect, useRef, useState } from 'react';
import { FaFan, FaLightbulb, FaSnowflake } from "react-icons/fa";
import { SensorAPI } from '../services/api.js';
import { connect, onMessage, sendAction } from '../services/ws.js';

Chart.register(LineController, LineElement, PointElement, LinearScale, CategoryScale, Legend, Tooltip);

function pad(n) { return n.toString().padStart(2, '0'); }
function hhmmss(date) {
    const d = typeof date === 'string' ? new Date(date) : date;
    return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

const getInitialState = () => {
    try {
        const savedState = localStorage.getItem("deviceState");
        if (savedState) {
            const parsed = JSON.parse(savedState);
            return {
                fan: !!parsed.fan,
                air: !!parsed.air,
                lamp: !!parsed.lamp,
            };
        }
    } catch (e) {
        console.error("Lỗi khi đọc trạng thái từ localStorage, sử dụng trạng thái mặc định.", e);
    }
    return { fan: false, air: false, lamp: false };
};

export default function Dashboard() {
    const chartRef = useRef(null);
    const chartInstanceRef = useRef(null);
    const [kpi, setKpi] = useState({ temperature: 0, humidity: 0, light: 0 });
    const timeoutsRef = useRef({});
    
    const [state, setState] = useState(getInitialState);
    const [displayState, setDisplayState] = useState(state);
    const [loading, setLoading] = useState({ fan: false, air: false, lamp: false });

    useEffect(() => {
        localStorage.setItem("deviceState", JSON.stringify(state));
        setDisplayState(state);
    }, [state]);

    useEffect(() => {
        connect();
        const off = onMessage((data) => {
            if (data.temperature !== undefined) {
                setKpi({ temperature: data.temperature, humidity: data.humidity, light: data.light });
                appendPoint({ t: new Date(), temp: data.temperature, hum: data.humidity, light: data.light });
            }

            if (['fan', 'air', 'lamp'].includes(data.device_id)) {
                if (timeoutsRef.current[data.device_id]) {
                    clearTimeout(timeoutsRef.current[data.device_id]);
                    delete timeoutsRef.current[data.device_id];
                }
                setState(currentState => ({ ...currentState, [data.device_id]: data.status === 'on' }));
                setLoading(l => ({ ...l, [data.device_id]: false }));
            }

            if (data.type === "device_disconnected") {
                setDisplayState({ fan: false, air: false, lamp: false });
            } else if (data.type === "device_connected") {
                console.log("Thiết bị đã kết nối lại. Gửi lại trạng thái đã lưu.");
                const lastState = getInitialState();
                setState(lastState);
                setDisplayState(lastState);
                Object.keys(lastState).forEach(device => {
                    sendAction({
                        device_id: device,
                        status: lastState[device] ? 'on' : 'off',
                        time: new Date().toLocaleString('sv-SE').replace('T', ' ').slice(0, 19)
                    });
                });
            }
        });
        return () => off();
    }, []);

    useEffect(() => {
        if (!chartRef.current) return;
        if (chartInstanceRef.current) { chartInstanceRef.current.destroy(); }
        const ctx = chartRef.current.getContext('2d');
        chartInstanceRef.current = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [
                    { label: 'Nhiệt độ', data: [], borderColor: '#f97316', tension: .4, fill: false, borderWidth: 2, yAxisID: 'y1' },
                    { label: 'Độ ẩm', data: [], borderColor: '#3b82f6', tension: .4, fill: false, borderWidth: 2, yAxisID: 'y1' },
                    { label: 'Ánh sáng', data: [], borderColor: '#16a34a', tension: .4, fill: false, borderWidth: 2, yAxisID: 'y2' }
                ]
            },
            options: {
                responsive: true, maintainAspectRatio: true,
                plugins: { legend: { display: true, position: 'top' }, tooltip: { mode: 'index', intersect: false } },
                scales: {
                    x: { grid: { display: false } },
                    y1: { type: 'linear', position: 'left', min: 0, max: 100, title: { display: true, text: 'Nhiệt độ (°C) / Độ ẩm (%)'}},
                    y2: { type: 'linear', position: 'right', min: 0, max: 1024, title: { display: true, text: 'Ánh sáng (Lux)'}, grid: { drawOnChartArea: false }}
                }
            }
        });
        return () => chartInstanceRef.current?.destroy();
    }, []);
    
    function appendPoint(p) {
        const chart = chartInstanceRef.current;
        if (!chart) return;
        const labels = chart.data.labels;
        const ds = chart.data.datasets;
        labels.push(hhmmss(p.t));
        if(labels.length > 8) labels.shift();
        ds[0].data.push(p.temp);
        ds[1].data.push(p.hum);
        ds[2].data.push(p.light);
        ds.forEach(d => { if(d.data.length > 8) d.data.shift() });
        chart.update('none');
    }

    function toggle(device) {
        if (loading[device]) return;
        const nextStatus = !displayState[device];
        setDisplayState(currentDisplay => ({ ...currentDisplay, [device]: nextStatus }));
        setLoading(l => ({ ...l, [device]: true }));
        sendAction({
            device_id: device,
            status: nextStatus ? 'on' : 'off',
            time: new Date().toLocaleString('sv-SE').replace('T', ' ').slice(0, 19)
        });
        if (timeoutsRef.current[device]) clearTimeout(timeoutsRef.current[device]);
        timeoutsRef.current[device] = setTimeout(() => {
            console.warn(`Không nhận được phản hồi cho thiết bị ${device}. Hoàn tác giao diện.`);
            setLoading(l => ({ ...l, [device]: false }));
            setDisplayState(state); 
        }, 5000);
    }

    return (
        <>
            <div className="header">
                <h1>Dashboard</h1>
            </div>

            <div className="kpi-grid">
                <div className="kpi-card temp"><p>Nhiệt độ</p><span>{kpi.temperature.toFixed(1)}°</span></div>
                <div className="kpi-card humid"><p>Độ ẩm</p><span>{kpi.humidity}%</span></div>
                <div className="kpi-card light"><p>Ánh Sáng</p><span>{kpi.light}</span></div>
            </div>

            <div className="main-panel">
                <div className="chart-container">
                    <h3>Biểu đồ</h3>
                    <div className="chart-wrapper">
                        <canvas ref={chartRef} />
                    </div>
                </div>
                <div className="controls-container">
                    <div className={`control-card lights ${!displayState.lamp ? 'off' : ''} ${loading.lamp ? 'is-loading' : ''}`}>
                        <div className="control-header">
                            <p>{displayState.lamp ? 'ON' : 'OFF'}</p>
                            <label className="switch"><input type="checkbox" checked={displayState.lamp} onChange={() => toggle('lamp')} disabled={loading.lamp} /><span className="slider round"></span></label>
                        </div>
                        <div className="control-body"><FaLightbulb size={32} /><p>Lights</p></div>
                    </div>
                    <div className={`control-card air-conditioner ${!displayState.air ? 'off' : ''} ${loading.air ? 'is-loading' : ''}`}>
                        <div className="control-header">
                            <p>{displayState.air ? 'ON' : 'OFF'}</p>
                            <label className="switch"><input type="checkbox" checked={displayState.air} onChange={() => toggle('air')} disabled={loading.air} /><span className="slider round"></span></label>
                        </div>
                        <div className="control-body"><FaSnowflake size={32} /><p>Air Conditioner</p></div>
                    </div>
                    <div className={`control-card fan ${!displayState.fan ? 'off' : ''} ${loading.fan ? 'is-loading' : ''}`}>
                        <div className="control-header">
                            <p>{displayState.fan ? 'ON' : 'OFF'}</p>
                            <label className="switch"><input type="checkbox" checked={displayState.fan} onChange={() => toggle('fan')} disabled={loading.fan} /><span className="slider round"></span></label>
                        </div>
                        <div className="control-body"><FaFan size={32} /><p>Fan</p></div>
                    </div>
                </div>
            </div>
        </>
    );
}