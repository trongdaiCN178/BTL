import { useState } from 'react';

import avatar from '../documents/avatar.jpg'; 

export default function Profile() {
    
    const [user, setUser] = useState({
        name: 'Trần Trọng Đại',
        msv: 'B22DCCN178',
        email: 'trongdaim10nhanmy@gmail.com',
        phone: '0774268625',
        github: 'https://github.com/trongdaiCN178',
        figma: 'https://www.figma.com/design/wfNA5FUXDJutgQAXRN9X7H/Figma-basics?node-id=627-1075&t=IVmdFOJlOURDdtof-0',
        document: 'https://drive.google.com/file/d/1pqoVm_OlW_FCn_8nFT-7dhkDg9aaqfwc/view?usp=sharing',
        apiDocument: 'http://localhost:8080/api-docs',
    });

    return (
        <>
            <div className="header"><h1>Profile</h1></div>

            <div className="profile-card">
                <div className="profile-header">
                    <div>
                        <h2>Thông tin tài khoản</h2>
                    </div>
                </div>
                
                <div className="profile-body">
                    <div className="profile-avatar">
                        <img src={avatar} alt="Avatar" />
                    </div>

                    <div className="profile-info">
                        <div className="info-field">
                            <label>Họ và tên:</label>
                            <span>{user.name}</span>
                        </div>
                         <div className="info-field">
                            <label>Mã sinh viên:</label>
                            <span>{user.msv}</span>
                        </div>
                        <div className="info-field">
                            <label>Email:</label>
                            <span>{user.email}</span>
                        </div>
                        <div className="info-field">
                            <label>Số điện thoại:</label>
                            <span>{user.phone}</span>
                        </div>
                    </div>
                </div>
            </div>

            <div className="profile-links content-card">
                <div className="info-field">
                    <label>Figma link:</label>
                    <span>{user.figma}</span>
                </div>
                <div className="info-field">
                    <label>GitHub link:</label>
                    <span>{user.github}</span>
                </div>
                <div className="info-field">
                    <label>Tài liệu:</label>
                    <span>{user.document}</span>
                </div>
                <div className="info-field">
                    <label>API Document:</label>
                    <span>{user.apiDocument}</span>
                </div>
            </div>
        </>
    );
}