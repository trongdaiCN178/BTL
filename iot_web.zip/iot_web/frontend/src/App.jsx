// src/App.jsx

import { NavLink, Route, Routes } from 'react-router-dom';
import { FaHome, FaChartBar, FaHistory, FaUser } from "react-icons/fa"; // Import icons
import ActionHistory from './pages/ActionHistory.jsx';
import Dashboard from './pages/Dashboard.jsx';
import DataSensor from './pages/DataSensor.jsx';
import Profile from './pages/Profile.jsx';

export default function App(){
	return (
		<div className="app">
			<aside className="sidebar">
				<div className="sidebar-header">
					<FaHome size={28} />
					<span>IoT Environment</span>
				</div>
				<nav className="sidebar-nav">
					<NavLink to="/" end>
						<FaChartBar />
						<span>Dashboard</span>
					</NavLink>
					<NavLink to="/sensor">
						<FaChartBar />
						<span>Data Sensor</span>
					</NavLink>
					<NavLink to="/actions">
						<FaHistory />
						<span>Action History</span>
					</NavLink>
					<NavLink to="/profile">
						<FaUser />
						<span>Profile</span>
					</NavLink>
				</nav>
			</aside>
			<main className="content">
				<Routes>
					<Route path="/" element={<Dashboard/>} />
					<Route path="/sensor" element={<DataSensor/>} />
					<Route path="/actions" element={<ActionHistory/>} />
					<Route path="/profile" element={<Profile/>} />
				</Routes>
			</main>
		</div>
	)
}